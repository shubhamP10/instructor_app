package com.mphasis.instructor_app.service;

import com.mphasis.instructor_app.model.Course;

import java.util.List;

public interface ICourseService {
    public Course insertCourse(Course course);
    public List<Course> getAllCourses();
}
